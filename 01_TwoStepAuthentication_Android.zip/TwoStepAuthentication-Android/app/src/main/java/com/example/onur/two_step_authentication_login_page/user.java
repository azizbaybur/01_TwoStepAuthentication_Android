package com.example.onur.two_step_authentication_login_page;

/**
 * Created by AzizBaybur on 1.10.2017.
 */

public class user {
    String userName;
    String encryptedPassword;


    user(String userName, String encryptedPassword) {
        this.userName = userName;
        this.encryptedPassword = encryptedPassword;


    }





}
